
//
//  KDFileManager.m
//  自定义Tabbar
//
//  Created by 韩军强 on 16/7/26.
//  Copyright © 2016年 CSC. All rights reserved.
//

#import "KDFileManager.h"

#define KDLuanMa @"1!1@2#3$4%5~>%%"
@interface KDFileManager ()


@end

@implementation KDFileManager
//static NSFileManager *fileManager;

//+(NSFileManager *)shareFileManager
//{
//    fileManager = [NSFileManager defaultManager];
//    return fileManager;
//}

#pragma mark -mrhan是否存在文件夹
+(BOOL)isExistFile:(NSString *)fileStr
{
//    fileName = [NSString stringWithFormat:@"%@.txt",fileName];
    NSString *path = [self documentPath:fileStr];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path]) {
        return YES;
    }else
    {
        return NO;
    }
    
}

#pragma mark -mrhan是否存在哪个文件夹下的哪个文件的路径
+(BOOL)isExistFile:(NSString *)fileStr andFileName:(NSString *)fileName
{
    NSString *path = [self documentPathFromFile:fileStr andFileName:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path]) {
        return YES;
    }else
    {
        return NO;
    }
    
}

/**
 *  自定义类型
 */
+(BOOL)isExistFile:(NSString *)fileStr andFileName:(NSString *)fileName type:(NSString *)type
{
    NSString *path = [self documentPathFromFile:fileStr andFileName:fileName type:type];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path]) {
        return YES;
    }else
    {
        return NO;
    }
    
}

#pragma mark -mrhan哪个文件下的哪个文件的路径
+(NSMutableDictionary *)dictionaryFromFile:(NSString *)fileStr andFileName:(NSString *)fileName
{
    
    NSString *path = [self documentPathFromFile:fileStr andFileName:fileName];

    NSMutableDictionary *mdic=[NSMutableDictionary dictionaryWithContentsOfFile:path];
    
    
    return mdic;
}

/**
 *  自定义类型
 */
+(NSMutableDictionary *)dictionaryFromFile:(NSString *)fileStr andFileName:(NSString *)fileName type:(NSString *)type
{
    
    NSString *path = [self documentPathFromFile:fileStr andFileName:fileName type:type];
    
    NSMutableDictionary *mdic=[NSMutableDictionary dictionaryWithContentsOfFile:path];
    
    
    return mdic;
}

#pragma mark -mrhan创建文件夹
+(id)createFile:(NSString *)fileStr
{
    
//    [self dataPath:fileName];

    if ([self isExistFile:fileStr]) {
        
        return nil;
    }else
    {
        
        NSString *path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",fileStr]];
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];

        
        //    NSString *result = [path stringByAppendingPathComponent:file];
        
        return path;
    }
    
    
}


////创建文件夹
//+ (NSString *)dataPath:(NSString *)fileName
//{
//    
////    NSFileManager *fileManager = [NSFileManager defaultManager]; // default is not thread safe
//    if ([self isExistFileName:fileName]) {
//        
//        return nil;
//    }else
//    {
//        
//        NSString *path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",fileName]];
//        BOOL bo = [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
//        NSAssert(bo,@"创建目录失败");
//        
//        //    NSString *result = [path stringByAppendingPathComponent:file];
//        
//        return path;
//    }
//    
//    
//}

#pragma mark -mrhan 获取文件夹的路径
+(NSString *)documentPath:(NSString *)fileName
{
    NSArray *doc=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *str1=[NSString stringWithFormat:@"%@/%@",[doc objectAtIndex:0],fileName];   //因为当前数组中就一个地址，所以为0。
    
    
    //    NSString *document=[str1 stringByAppendingPathComponent:fileName];
    
    return str1;
}

#pragma mark -mrhan 哪个文件夹下面的哪个文件
+(NSString *)documentPathFromFile:(NSString *)fileStr andFileName:(NSString *)fileName
{
    fileName = [NSString stringWithFormat:@"%@.txt",fileName];
    
    NSString *filePath=[[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:fileStr] stringByAppendingPathComponent:fileName];
    
    return filePath;
}

/**
 *  自定义类型
 */
+(NSString *)documentPathFromFile:(NSString *)fileStr andFileName:(NSString *)fileName type:(NSString *)type
{
    fileName = [NSString stringWithFormat:@"%@.%@",fileName,type];
    
    NSString *filePath=[[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:fileStr] stringByAppendingPathComponent:fileName];
    
    return filePath;
}

//--------------------------缓存大小以及清理------------------------------------------
// 缓存大小
+ (CGFloat)fileSizeWhich:(int)which{
    CGFloat fileSize;
    
    //获取路径
    NSString *cachePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES)firstObject];
    NSLog(@"no1=%@",cachePath);
    //获取所有文件的数组
    NSArray *files = [[NSFileManager defaultManager] subpathsAtPath:cachePath];
    
    NSLog(@"文件数：%ld",files.count);
    
    for(NSString *path in files) {

        NSString*filePath = [cachePath stringByAppendingString:[NSString stringWithFormat:@"/%@",path]];
        //累加
        fileSize += [[NSFileManager defaultManager]attributesOfItemAtPath:filePath error:nil].fileSize;
    }
    //转换为M为单位
    CGFloat sizeM = fileSize /1024.0/1024.0;
    
    return sizeM;
}

// 缓存大小
+ (CGFloat)fileSizeWhich:(int)which ExceptFile1:(NSString *)str1 File2:(NSString *)str2{
    CGFloat fileSize;
    
    //如果传进来的字符串为nil，在这里设置为乱码。
    if (str1 == nil) {
        str1 =KDLuanMa;
    }
    if (str2 == nil)
    {
        str2 =KDLuanMa;
    }
    
    //Documents还是Caches
    NSString *whichPath=[self FileFromWhich:which];
    
    //获取所有文件的数组
    NSArray *files = [[NSFileManager defaultManager] subpathsAtPath:whichPath];
    
    NSLog(@"文件数：%ld",files.count);

    for(NSString *path in files) {
        
        if ([path hasSuffix:str1]||[path hasSuffix:str2]) {
            continue;
        }
        
        //累加
        fileSize += [[NSFileManager defaultManager]attributesOfItemAtPath:path error:nil].fileSize;
    }
    //转换为M为单位
    CGFloat sizeM = fileSize /1024.0/1024.0;
    
    return sizeM;
}

//Documents还是Caches
+ (void)removeCacheWhich:(int)which{
    //===============清除缓存==============
    //获取路径
    NSString *cachePath=[self FileFromWhich:which];
    
    //返回路径中的文件数组
    NSArray*files = [[NSFileManager defaultManager]subpathsAtPath:cachePath];
    
    NSLog(@"文件数：%ld",[files count]);
    for(NSString *p in files){
        NSError*error;
        
        NSString*path = [cachePath stringByAppendingString:[NSString stringWithFormat:@"/%@",p]];
        
        if([[NSFileManager defaultManager]fileExistsAtPath:path])
        {
            BOOL isRemove = [[NSFileManager defaultManager]removeItemAtPath:path error:&error];
            if(isRemove) {
                NSLog(@"清除成功");
                //这里发送一个通知给外界，外界接收通知，可以做一些操作（比如UIAlertViewController）
                
            }else{
                
                NSLog(@"清除失败");
                
            }
        }
    }
}



+ (void)removeCacheWhich:(int)which ExceptFile1:(NSString *)str1 File2:(NSString *)str2{
    
    //如果传进来的字符串为nil，在这里设置为乱码。
    if (str1 == nil) {
        str1 =KDLuanMa;
    }
    if (str2 == nil)
    {
        str2 =KDLuanMa;
    }
    
    //Documents还是Caches
    NSString *whichPath=[self FileFromWhich:which];
    
    //返回路径中的文件数组
    NSArray*files = [[NSFileManager defaultManager]subpathsAtPath:whichPath];
    
    NSLog(@"文件数：%ld",[files count]);
    for(NSString *path in files){
        NSError*error;
        
        NSString*KDPath = [whichPath stringByAppendingString:[NSString stringWithFormat:@"/%@",path]];

        if ([KDPath hasSuffix:str1]||[KDPath hasSuffix:str2]) {
            continue;
        }
        if([[NSFileManager defaultManager]fileExistsAtPath:KDPath])
        {
            BOOL isRemove = [[NSFileManager defaultManager]removeItemAtPath:KDPath error:&error];
            if(isRemove) {
                NSLog(@"清除成功");
                //这里发送一个通知给外界，外界接收通知，可以做一些操作（比如UIAlertViewController）
                
            }else{
                
                NSLog(@"清除失败");
                
            }
        }
    }
}

//Documents还是Caches
+(NSString *)FileFromWhich:(int)which
{
        NSString *whichPath=nil;

            if (which==1)
            {
                //获取路径Caches
                whichPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES)objectAtIndex:0];
                return whichPath;
            }else
            {
                //获取路径(默认为Documents)
                whichPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES)firstObject];
                return whichPath;
            }

}


@end
