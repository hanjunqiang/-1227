//
//  KDFileManager.h
//  自定义Tabbar
//
//  Created by 韩军强 on 16/7/26.
//  Copyright © 2016年 CSC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface KDFileManager : NSObject

/**
 *  创建文件，默认是在Document文件下创建。
 */
+(id)createFile:(NSString *)fileStr;
/**
 *  是否存在该文件夹
 */
+(BOOL)isExistFile:(NSString *)fileStr;

/**
 * 是否存在该文件夹
 */
+(BOOL)isExistFile:(NSString *)fileStr andFileName:(NSString *)fileName;
/**
 * 是否存在该文件夹下的某个文件
 */
+(BOOL)isExistFile:(NSString *)fileStr andFileName:(NSString *)fileName type:(NSString *)type;

/**
 *  哪个文件下哪个名字的数据（默认为.txt）
 */
+(NSMutableDictionary *)dictionaryFromFile:(NSString *)fileStr andFileName:(NSString *)fileName;
/**
 *  哪个文件下哪个名字的数据（数据类型自定义，传类型名字即可，不传“.”）
 */
+(NSMutableDictionary *)dictionaryFromFile:(NSString *)fileStr andFileName:(NSString *)fileName type:(NSString *)type;

//获取文件夹的路径
+(NSString *)documentPath:(NSString *)fileName;

//哪个文件夹下面的哪个文件
+(NSString *)documentPathFromFile:(NSString *)fileStr andFileName:(NSString *)fileName;
+(NSString *)documentPathFromFile:(NSString *)fileStr andFileName:(NSString *)fileName type:(NSString *)type;


/**
 *  清除缓存which:0是Documents,1是Caches ，str1和str2为排除的文件名。
 *  @param which 0或1   ---0是Documents,1是Caches
 *  @param str1  排除的文件名1,没有传nil
 *  @param str2  排除的文件名2,没有传nil
 *
 *  @return CGFloat类型
 */
+ (CGFloat)fileSizeWhich:(int)which ExceptFile1:(NSString *)str1 File2:(NSString *)str2;
//沙河中所有的文件的大小
+ (CGFloat)fileSizeWhich:(int)which;


/**
 *  清除缓存which:0是Documents,1是Caches ，str1和str2为排除的文件名。
 *
 *  @param which 0或1   ---0是Documents,1是Caches
 *  @param str1  排除的文件名1,没有传nil
 *  @param str2  排除的文件名2,没有传nil
 */
+ (void)removeCacheWhich:(int)which ExceptFile1:(NSString *)str1 File2:(NSString *)str2;
//清除沙河中所有的文件
+ (void)removeCacheWhich:(int)which;

@end
