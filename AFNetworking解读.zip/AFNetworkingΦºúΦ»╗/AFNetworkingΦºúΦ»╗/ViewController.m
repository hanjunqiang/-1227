//
//  ViewController.m
//  AFNetworking解读
//
//  Created by 韩军强 on 16/6/24.
//  Copyright © 2016年 ios. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "AFHTTPSessionManager.h"
#import "UIKit+AFNetworking.h"
#import "AFImageDownloader.h"
#import "KDFileManager.h"


//播放视频
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
@interface ViewController ()

@property (nonatomic, strong) AVPlayerViewController *playerViewController;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -mrhan当前的网络连接状态监测
- (IBAction)Button1:(id)sender {
    
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        NSLog(@"Reachability: %@", AFStringFromNetworkReachabilityStatus(status));
    }];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    
}

#pragma mark -mrhan模拟请求方式
- (IBAction)Button2:(id)sender {
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    // 设置请求格式
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    // 设置返回格式
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSString *path=@"https://api.map.baidu.com/telematics/v3/weather?location=嘉兴&output=json&ak=5slgyqGDENN7Sy7pw29IUvrZ";
    path=[path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [manager POST:path parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
        NSLog(@"uploadProgress===%@",uploadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"responseObject====%@",responseObject);
        
        NSDictionary *dic=[NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        NSLog(@"dic====%@",dic);

        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
    
    
//    [manager POST:path parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
//        
//    } progress:^(NSProgress * _Nonnull uploadProgress) {
//        
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        
//    }];
    
    
    
}
#pragma mark -mrhan上传图片（单张和多张上传的方式一样）
- (IBAction)Button3:(id)sender {
    
    NSString *path =@"网址";
    UIImage *image; //这里是将要上传的图片
    
    NSMutableDictionary *dic=[NSMutableDictionary dictionary];
    [dic setObject:@"uid" forKey:@"uid"];
    
    AFHTTPSessionManager *manager=[AFHTTPSessionManager manager];
    [manager setResponseSerializer:[AFHTTPResponseSerializer serializer]];

    [manager POST:path parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        //多张上传的时候，就是在这里写一个for循环进行一张一张的进行上传
        NSData *data =UIImageJPEGRepresentation(image, 0.3);
        [formData appendPartWithFileData:data name:@"后台给的图片参数名" fileName:@"后台给的图片参数名.png/.jpeg/.jpg" mimeType:@"image/jpeg"];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *diction=[NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        NSLog(@"diction=%@",diction);

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error=%@",error);
    }];
    
//    [manager POST:nil parameters:dic success:^(NSURLSessionDataTask *task, id responseObject) {
//        
//        NSDictionary *diction=[NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
//        NSLog(@"diction=%@",diction);
//        
//    } failure:^(NSURLSessionDataTask *task, NSError *error) {
//        NSLog(@"error=%@",error);
//    }];
    
}


- (IBAction)Button4:(id)sender {


    NSString *url =@"http://116.228.173.50:19581/magazine/userfiles/files/magazine/magazine/magazine/2016/09/076641b84c5349c4965b57fe6750a25e.mp4";
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //下载都Documents文件下，并取名为UIWebViewDemo.zip（格式就是zip格式）
    NSString *filePath = [[NSHomeDirectory()stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"video.mp4"];
    
//------------------------------------------无下载路径---------------------------------------------
//    // 下载任务
//    NSURLSessionDownloadTask *task = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
//        
//        // 下载地址   targetPath 为默认下载地址
//        
////        if (!filePath){return targetPath;}
//        
//        return [NSURL fileURLWithPath:filePath];
//        
//        
//    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
//        
//        
//        // 下载完成调用的方法
//        if (error) {
//            NSLog(@"error---%@",error);
//        }else{
//            
//            NSLog(@"resp---%@",response);
//            NSLog(@"下载成功！");
//            NSLog(@"filePath---%@",filePath);
//            
//        }
//    }];
//------------------------------------------有下载进度---------------------------------------------
        NSURLSessionDownloadTask *task = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
    
            // 打印下下载进度
            NSLog(@"进度:%lf  完成进度：%lld  总进度：%lld",1.0 * downloadProgress.completedUnitCount / downloadProgress.totalUnitCount,downloadProgress.completedUnitCount,downloadProgress.totalUnitCount);
    
//            if (progress) {progress(downloadProgress);}
    
        } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
    
            // 下载地址   targetPath 为默认下载地址
    
            if (!filePath){return targetPath;}
    
            return [NSURL fileURLWithPath:filePath];
    
        } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
    
            // 下载完成调用的方法
            if (error) {
                NSLog(@"err---%@",error);
            }else{
                NSLog(@"sp---%@,filePath---%@",response,filePath);
            }
    
        }];
    //
    //开始启动任务
    [task resume];
    
    
}
- (IBAction)Button5:(id)sender {
    
//    NSString *path = [[NSHomeDirectory()stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"music.mp3"];
//
//    //播放本地音频
//    _player=[[AVAudioPlayer alloc]initWithData:[NSData dataWithContentsOfFile:path] error:nil];;
    //    sleep(300);
    
    if (_player==nil) {
        
        [self.player play];    //这里要设成全局变量，播放。
    }else
    {
        _player = nil;   //清空重新播放
    }

    //播放视频
//    [self presentViewController:self.playerViewController animated:YES completion:nil];


}


//播放音乐
-(AVAudioPlayer *)player
{
    if (_player==nil) {
        NSString *path = [[NSHomeDirectory()stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"music.mp3"];
        //播放本地音频
        _player=[[AVAudioPlayer alloc]initWithData:[NSData dataWithContentsOfFile:path] error:nil];;
        //    sleep(300);
        
//        [_player play];    //这里要设成全局变量，播放。
    }
    
    return _player;
}

//#import <AVFoundation/AVFoundation.h>
//#import <AVKit/AVKit.h>
//@property (strong, nonatomic) AVPlayerViewController *playerVC;
//用法：[self presentViewController:self.playerViewController animated:YES completion:nil];
// REMARKS: 使用AVKit/AVKit框架中的AVPlayerViewController播放视频
- (AVPlayerViewController *)playerViewController //懒加载避免重复调用
{
    if (_playerViewController == nil) {
        
//        NSURL *url = [NSURL URLWithString:@"http://v1.mukewang.com/19954d8f-e2c2-4c0a-b8c1-a4c826b5ca8b/L.mp4"];

        NSString *path = [[NSHomeDirectory()stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"music.mp3"];
        NSURL *url = [NSURL fileURLWithPath:path];
        AVPlayer *player = [AVPlayer playerWithURL:url];
        
        _playerViewController = [[AVPlayerViewController alloc] init];
        _playerViewController.player = player;

    }
    return _playerViewController;
}


- (IBAction)button6:(id)sender {
    
    [KDFileManager fileSizeWhich:0]; //沙河中所有的文件的大小
    //排除名字为什么什么的文件
    //    NSLog(@"no1=%.2f",[KDFileManager fileSizeWhich:0 ExceptFile1:nil File2:nil]);
    
}

- (IBAction)button7:(id)sender {
    
    [KDFileManager removeCacheWhich:0];//清除沙河中所有的文件
    //排除名字为什么什么的文件
    //    [KDFileManager removeCacheWhich:0 ExceptFile1:@"1.png" File2:nil];
    
}
- (IBAction)button8:(id)sender {
    
}

- (IBAction)button9:(id)sender {
    
}

- (IBAction)button10:(id)sender {
    
}

@end
