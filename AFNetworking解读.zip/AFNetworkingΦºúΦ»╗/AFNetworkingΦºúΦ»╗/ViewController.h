//
//  ViewController.h
//  AFNetworking解读
//
//  Created by 韩军强 on 16/6/24.
//  Copyright © 2016年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController

@property(strong,nonatomic)AVAudioPlayer *player;   //这里的要声明成全局的，不然有bug，（有的耳机也是不响）

@end

