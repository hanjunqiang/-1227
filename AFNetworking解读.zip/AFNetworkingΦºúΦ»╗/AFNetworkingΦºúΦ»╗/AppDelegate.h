//
//  AppDelegate.h
//  AFNetworking解读
//
//  Created by 韩军强 on 16/6/24.
//  Copyright © 2016年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

